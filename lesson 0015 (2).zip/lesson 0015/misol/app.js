var a=4
var b=67
console.log(a*b)