const menu = document.querySelector("#menu");
const sidebar = document.querySelector(".sidebar");
const back = document.querySelector("#back");
const muun = document.querySelector("#muun");
const suun = document.querySelector("#suun");
const container = document.querySelector(".container")
const back1 = document.querySelector("#back1");
const storistvideo = document.querySelector(".storist-video");
const back2 = document.querySelector("#back2");
const storistvideo1 = document.querySelector(".storist-video1");
const back3 = document.querySelector("#back3");
const storistvideo2 = document.querySelector(".storist-video2");
const back4 = document.querySelector("#back4");
const storistvideo3 = document.querySelector(".storist-video3");
const faheart = document.querySelector(".fa-heart")
const rasm1 = document.querySelector(".rasm1")
const rasm2 = document.querySelector(".rasm2")
const rasm3 = document.querySelector(".rasm3")
const rasm4 = document.querySelector(".rasm4")
const sozlamalar = document.querySelector(".sozlamalar")
const sozlama = document.querySelector(".sozlama")
const bolim = document.querySelector(".bolim")

menu.addEventListener("click", () => {
    sidebar.style = "margin-left:0px;"
})
back.addEventListener("click", () => {
    sidebar.style = "margin-left:-400px;"
})
// muun.addEventListener("click", () => {
//     container.style = "background:black"
//     sidebar.style.background = "black"

// })
// muun.addEventListener("click", () => {
//     container.style = "background:white"
//     sidebar.style.background = "white"

// })
rasm1.addEventListener("click" , () => {
    container.style = "display:none" 
    storistvideo.style = "display:block";
})

back1.addEventListener("click", () =>{
    container.style = "display:block"
    storistvideo.style = "display:none";
})
rasm2.addEventListener("click" , () => {
    container.style = "display:none" 
    storistvideo1.style = "display:block";
})

back2.addEventListener("click", () =>{
    container.style = "display:block"
    storistvideo1.style = "display:none";
})
rasm3.addEventListener("click" , () => {
    container.style = "display:none" 
    storistvideo2.style = "display:block";
})

back3.addEventListener("click", () =>{
    container.style = "display:block"
    storistvideo2.style = "display:none";
})
rasm4.addEventListener("click" , () => {
    container.style = "display:none" 
    storistvideo3.style = "display:block";
})

back4.addEventListener("click", () =>{
    container.style = "display:block"
    storistvideo3.style = "display:none";
})

sozlamalar.addEventListener("click" , () =>{
  bolim.style = "display:none"
  sozlama.style = "display:block"
})

faheart.addEventListener("click" , () => {
    faheart.style = "background: red; border-radius: 5px 5px 20px 20px;"
    
})