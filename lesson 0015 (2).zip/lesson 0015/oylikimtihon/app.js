const tun = document.querySelector(".tun")
const kun = document.querySelector(".kun")
const container = document.querySelector(".container")
const navbar = document.querySelector(".navbar")
const facebook = document.querySelector(".facebook")
const zoom = document.querySelector("#zoom")
const x = document.querySelector(".x")
const x1 = document.querySelector(".x1")
const x2 = document.querySelector(".x2")
const men = document.querySelector(".men")
const men1 = document.querySelector(".men1")
const men2 = document.querySelector(".men2")
const men3 = document.querySelector(".men3")
const chiziq = document.querySelector(".chiziq")
const uy = document.querySelector(".uy")
const tv = document.querySelector(".tv")
const odam = document.querySelector(".odam")
const market = document.querySelector(".market")
const bell = document.querySelector(".bell")
const avatar = document.querySelector(".avatar")
const avatarinput = document.querySelector(".avatar-input")
const hikoya = document.querySelector(".hikoya")
const video = document.querySelector(".video")
const aylana = document.querySelector(".aylana")


bell.addEventListener("click" , () =>{
    chiziq.style = "margin-left:380px"
    avatar.style = "display:none"
    avatarinput.style = "display:none"
    hikoya.style = "display:none"
    video.style = "display:none"
    aylana.style = "display:none"
    
})

market.addEventListener("click" , () =>{
    chiziq.style = "margin-left:380px"
    avatar.style = "display:none"
    avatarinput.style = "display:none"
    hikoya.style = "display:none"
    video.style = "display:none"
    aylana.style = "display:none"
    
})

odam.addEventListener("click" , () =>{
    chiziq.style = "margin-left:380px"
    avatar.style = "display:none"
    avatarinput.style = "display:none"
    hikoya.style = "display:none"
    video.style = "display:none"
    aylana.style = "display:none"
    
})
tv.addEventListener("click" , () =>{
    chiziq.style = "margin-left:380px"
    avatar.style = "display:none"
    avatarinput.style = "display:none"
    hikoya.style = "display:none"
    video.style = "display:none"
    aylana.style = "display:none"
    
})

uy.addEventListener("click" , () =>{
    chiziq.style = "margin-left:380px"
    avatar.style = "display:block"
    avatarinput.style = "display:block"
    hikoya.style = "display:block"
    video.style = "display:block"
    aylana.style = "display:block"
    
})

market.addEventListener("click" , () =>{
    chiziq.style = "margin-left:280px"
})

odam.addEventListener("click" , () =>{
    chiziq.style = "margin-left:180px"
})

tv.addEventListener("click" , () =>{
    chiziq.style = "margin-left:80px"
})
uy.addEventListener("click" , () =>{
    chiziq.style = "margin-left:0px"
})

x.addEventListener("click" , () => {
    men1.style = "display:none; "
    x1.style = "margin-left:-150px"
    x2.style = "margin-left:-150px"
})
x1.addEventListener("click" , () => {
    men2.style = "display:none;"
    x2.style = "margin-left:-300px"
})
x2.addEventListener("click" , () =>{
    men3.style = "display:none;"
})


tun.addEventListener("click" , () => {
    container.style = "background:black"
    tun.style = "display:none; color:white;"
    kun.style = "display:block; color:white;"
    navbar.style = "background:black"
    facebook.style = "color:white"
    color.style = "color:white"
})
kun.addEventListener("click" , () => {
    container.style = "background:grey"
    tun.style = "display:block"
    kun.style = "display:none"
    navbar.style = "background:red"
    facebook.style = "color:black"
    color.style = "color:black"
})
