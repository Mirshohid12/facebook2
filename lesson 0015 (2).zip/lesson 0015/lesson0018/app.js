const en = document.querySelector('.site_name');
const country = document.querySelector('.country');
const temp = document.querySelector('.temp');
const holat = document.querySelector('.holat');
const localtime = document.querySelector('.localtime');
const date1 = document.querySelector('.date1');
const date2 = document.querySelector('.date2 ');
const date3 = document.querySelector('.date3');
const statusImage = document.querySelector(".status_image");
const form = document.querySelector("form");
const searchInput = document.querySelector('#search');
const loader = document.querySelector("#loader");
const days = document.querySelector('.kunlar');
const clearInput = document.querySelector('#clear_input');
const fasearch = document.querySelector(".fa-search")
const searchbar = document.querySelector(".searchbar")
const kun1 = document.querySelector(".kun1")
const tun = document.querySelector(".tun")
const maincontaainer = document.querySelector(".main_contaainer")

tun.addEventListener("click" , () => {})

kun1.addEventListener("click" , () =>{
    maincontaainer.style = "background:aqua;"
    kun1.style = "display:none;"
    tun.style = "display:block"
    kun_date.style = "background:aqua"
})





fasearch.addEventListener("click" , () => {
    searchbar.style = "margin-left:-800px"
})
checkTheLoading(false);

function checkTheLoading(status) {
    if (status) {
        loader.style.display = "block"
    } else {
        loader.style.display = " none"
    }
}

form.addEventListener('submit', searchPlace);

async function searchPlace(e) {

    checkTheLoading(true)
    e.preventDefault();
    try {
        await axios.get(`https://api.weatherapi.com/v1/forecast.json?key=644f6ce0ca9e401ebb891832211707&q=${searchInput.value}&days=7&aqi=yes&alerts=yes1`)
            .then(weatherData => loadAllData(weatherData.data))
            .catch(err => {
                checkTheLoading(false)
                console.log(err)
            })
    } catch (err) {
        console.log(err)
    }
    searchInput.value = "";
}

(
    async function () {
        try {
            await axios.get("https://api.weatherapi.com/v1/forecast.json?key=644f6ce0ca9e401ebb891832211707&q=Namangan&days=7&aqi=yes&alerts=yes")
                .then(weatherData => loadAllData(weatherData.data))
                .catch(err => console.log(err))
        } catch (err) {
            console.log(err)
        }
    }()
)

function loadAllData(malumot) {
    checkTheLoading(false);

    en.innerHTML = malumot.location.name;
    country.innerHTML = malumot.location.region + " " + malumot.location.country;
    temp.innerHTML = malumot.current.temp_c + " " + "°C";
    holat.innerHTML = malumot.current.condition.text;
    localtime.innerHTML = malumot.location.localtime;
    statusImage.src = malumot.current.condition.icon;
    days.innerHTML = '';
    malumot.forecast.forecastday.forEach(kun => {
        const div = document.createElement('div');
        div.className = 'kun';
        div.innerHTML = `
        <p class ="kun_date">${kun.date}</p>
        <p>Average temperatura in this day</p>
        <div class ="avrg_temp"></div>

        <div class="kun_option">
            <div class="option">
            <div class="circle_diagramm">
                    <div class="percent_show"> <h6 class="humidity_perc">${
                    kun.day.avghumidity
                    }%</h6></div>
                    <div class="diagramm_filter" style="height:  ${
                    kun.day.avghumidity
                    }%"></div>
                    </div>
            </div>
            <div class="option">
            <p>${kun.hour[0].pressure_mb} hPa</p>
            </div>
            <div class="option">
            <div class= "wind_km">${kun.hour[0].wind_kph}<br>km/h</div>
            <div class = "arrow" style = "transform:rotate(${kun.hour[0].wind_degree}deg)"></div>
            </div>
        </div>
        <div class="sun_moon"></div>
        `
        days.appendChild(div)
    })
}
clearInput.addEventListener('click', () => {
    searchInput.value = ""
})