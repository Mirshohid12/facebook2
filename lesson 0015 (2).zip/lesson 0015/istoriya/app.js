const storist = document.querySelector(".storist")
const birinchi = document.querySelector(".birinchi")
const back = document.querySelector("#back");
const storistvideo = document.querySelector(".storist-video");
const faheart = document.querySelector(".fa-heart")

birinchi.addEventListener("click", () =>{
    storist.style = "display:none"
    storistvideo.style = "display:block";
})
back.addEventListener("click", () =>{
    storist.style = "display:block"
    storistvideo.style = "display:none";
})


faheart.addEventListener("click" , () => {
    faheart.style = "background: red; border-radius: 5px 5px 20px 20px;"
    
})