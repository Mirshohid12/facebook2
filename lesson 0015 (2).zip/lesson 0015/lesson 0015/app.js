const input = document.querySelector("#input");
const form = document.querySelector("form");

const collection = document.querySelector('.collection');
const menu1 = document.querySelector("#menu1");
const menu = document.querySelector(".menu");

const doc = document.querySelector(".doc")
const doc1 = document.querySelector(".doc1")
const smile = document.querySelector("#smile")
const keyboard = document.querySelector("#keyboard")




smile.addEventListener("click", () => {
    smile.style = "display:none"
    keyboard.style = "display:block"
    doc.style = "display:block"
    doc1.style = "display:none"
})
keyboard.addEventListener("click", () =>{
    smile.style = "display:block"
    keyboard.style = "display:none"
    doc.style = "display:none"
    doc1.style = "display:block"
})

form.addEventListener('submit', createReminder);

function createReminder(e){
    e.preventDefault();  // saytni reflesh berishini to'xtatadi.yangilamaydi saytni
    let chislo = new Date();
    function correctTime(soat, minut){
        if(soat < 10){
            return `0${chislo.getHours()} : ${chislo.getMinutes()}`
        }
        else if(minut < 10){
            return `${chislo.getHours()} : 0${chislo.getMinutes()}`
        }
        else{
            return `${chislo.getHours()} : ${chislo.getMinutes()}`
        }
    }

    const todolistLi = document.createElement('li');
    const p = document.createElement('p');
    const div = document.createElement('div');
    div.innerHTML = `<span>${correctTime(chislo.getHours(), chislo.getMinutes())}</span><i class="fas fa-edit"></i> <i class="fas fa-check-circle"></i><i class="fas fa-trash"></i> `
    p.innerHTML = input.value;
    todolistLi.appendChild(p);
    todolistLi.appendChild(div)
    todolistLi.className = "collection__item";
    collection.appendChild(todolistLi);
    console.log(input.value);
    input.value = '';
    div.lastChild.addEventListener('click', (e) => {
        e.target.parentElement.parentElement.remove();
    })
    div.children[2].addEventListener('click', () => {
        todolistLi.firstChild.classList.toggle("complete");
    })

    div.children[1].addEventListener('click', () => {
        if(p.hasAttribute("contenteditable")){
            p.removeAttribute("contenteditable")
            div.children[1].className = "fas fa-edit";
        }
        else{
            p.setAttribute("contenteditable", true)
            div.children[1].className = "fas fa-check-double";
        }
    })
    todolistLi.addEventListener('dblclick',() => {
        todolistLi.firstChild.classList.toggle("complete");
    })
}



const container = document.querySelector(".container");
const quti = document.querySelector(".box");
const yes = document.querySelector(".btn1");
const no = document.querySelector(".btn2");
 const button3 = document.querySelector(".btn3");


button3.addEventListener('click', () => {
    container.style.display = "none";
    quti.style.display = "block";
});
yes.addEventListener('click', () => {
    quti.style.display = "none"
    container.style.display = "block";
    // 1-yo'li
    collection.innerHTML = '';
    // 2-yo'li
    // while(collection.firstChild){
    //     collection.removeChild(collection.firstChild);
    // }
});
no.addEventListener('click', () => {
    quti.style.display = "none"
    container.style.display = "block";
});

menu1.addEventListener('click',() => {
  menu.style.display = "block";
});
menu1.addEventListener("dblclick",() => {
     menu.style.display = "none"; 
})



search.addEventListener('keyup',() => {
    const allLi = document.querySelectorAll(".collection_item");
    const searchInputValue = search.value.toLowerCase();

    allLi.forEach(f=>{
        if(f.firstChild.textContent.toLowerCase().indexOf.of(searchInputValue)===-1){
            f.style.display = "none";

        }
        else{
            f.style.display = "flex";
        }
    })
})



// const doc = document.querySelector(".doc")
// const doc1 = document.querySelector(".doc1")
// const smile = document.querySelector("#smile")
// const keyboard = document.querySelector("#keyboard")

// smile.addEventListener("click", () => {
//     // smile.style = "display:none"
//     keyboard.style = "display:block"
//     doc.style = "display:block"
//     doc1.style = "display:none"
// })