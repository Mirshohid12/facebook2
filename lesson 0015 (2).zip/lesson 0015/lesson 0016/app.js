
const input = document.querySelector("#input");
const form = document.querySelector("form");

const collection = document.querySelector('.collection');
const menu1 = document.querySelector("#menu1");
const menu = document.querySelector(".menu");
const main = document.querySelector(".main")
const main1 = document.querySelector(".main1")
const form1 = document.querySelector(".form1")
const inputnumber = document.querySelector(".input_number");
const inputValue = document.querySelector(".input1");
const ism1 = document.querySelector(".ism1")
const orqaga =document.querySelector(".orqaga")

form1.addEventListener("submit" , (event) =>{
    event.preventDefault();
    let inputValue = inputnumber.value
    if(inputValue === "12345678"){
        main.style = "display:block";
        main1.style = "display:none";
    }
    else{
        main1.style.display = "block" 
    }

    inputnumber.value =""

})
ism1.addEventListener("click", () =>{
  main.style.display = "none"
  container.style.display = "block"
})



form.addEventListener('submit', createReminder);
    
collection.addEventListener("click", () => {
    menu.style.display = "none";
})


function createReminder(e){
    e.preventDefault();  // saytni reflesh berishini to'xtatadi.yangilamaydi saytni
    let chislo = new Date();
    function correctTime(soat, minut){
        if(soat < 10){
            return `0${chislo.getHours()} : ${chislo.getMinutes()}`
        }
        else if(minut < 10){
            return `${chislo.getHours()} : 0${chislo.getMinutes()}`
        }
        else{
            return `${chislo.getHours()} : ${chislo.getMinutes()}`
        }
    }

    const todolistLi = document.createElement('li');
    const p = document.createElement('p');
    const div = document.createElement('div');
    div.innerHTML =  `<span>${correctTime(chislo.getHours(), chislo.getMinutes())}</span><i class="fas fa-edit"></i> <i class="fas fa-check-circle"></i><i class="fas fa-trash"></i>` 
    p.innerHTML = input.value;
    todolistLi.appendChild(p);
    todolistLi.appendChild(div)
    todolistLi.className = "collection_item";
    collection.appendChild(todolistLi);
    console.log(input.value);
    input.value = '';
    div.lastChild.addEventListener('click', (e) => {
        e.target.parentElement.parentElement.remove();
        e.target.parentElement = style
    })
    div.children[2].addEventListener('click', () => {
        todolistLi.firstChild.classList.toggle("complete");
    })

    div.children[1].addEventListener('click', () => {
        if(p.hasAttribute("contenteditable")){
            p.removeAttribute("contenteditable")
            div.children[1].className = "fas fa-edit";
        }
        else{
            p.setAttribute("contenteditable", true)
            div.children[1].className = "fas fa-check-double";
        }
    })
    todolistLi.addEventListener('dblclick',() => {
        todolistLi.firstChild.classList.toggle("complete");
    })
}


const todolistinput = document.querySelector(".todolist_input");

todolistinput.addEventListener("click", () =>{
    todolistinput.style = "margin-top:0px;";
    box.style.display = "none"
})
collection.addEventListener("click", () =>{
    todolistinput.style = "margin-top:245px;";
})

const container = document.querySelector(".container");
const yes = document.querySelector(".btn1");
const no = document.querySelector(".btn2");
 const button3 = document.querySelector(".btn3");
 const klav = document.querySelector('.klav');
 const emoji1 = document.querySelector('.emoji1');
 const changer = document.querySelector('.changer');
 const changer1 = document.querySelector('.changer1');


 menu1.addEventListener("click", () => {
    menu.style = "display:block;";
 })


 input.addEventListener('click',()=>{
    klav.style.display = "block";
 })



 const menuitem1 = document.querySelector(".menu-item1");
const box = document.querySelector(".box");
  menuitem1.addEventListener("click", () =>{
    box.style = "display:block;";
    //  container.style = "background:rgba(128, 128, 128, 0.516); "
   
    menu.style = "display:none;";
  })
//  container.addEventListener('click',()=>{
//     klav.style.display = "none";
//  })


 changer.addEventListener('click',()=>{
    klav.style.display = "none";
    emoji1.style.display = "block";
    changer1.style.display = "block";
    changer.style.display = "none";
 })
 changer1.addEventListener('click',()=>{
    emoji1.style.display = "none";
    klav.style.display = "block";
    changer.style.display = "block";
    changer1.style.display = "none";
 })
 emoji1.addEventListener('click',()=>{
    emoji1.innerHTML = `😀😁😂🤣😃😄😅😉😎😍😘🥰😗😙🥲😚🤗🤩🤔🫡🤨😐😑😶🙄😣😥😮🤐😯😪😫🥱😴😌😛😜😝🤤😒`
 })
 const collectionitem = document.querySelector(".collection_item");
 yes.addEventListener('click', () => {
    // collectionitem.style = "display:none;";
    
    
    box.style.display = "none"
    // // 1-yo'li
    collection.innerHTML = '';
    // 2-yo'li
    // while(collection.firstChild){
    //     collection.removeChild(collection.firstChild);
    // }
});


no.addEventListener('click', () => {
    box.style.display = "none"
   
});











search.addEventListener('keyup',() => {
    const allLi = document.querySelectorAll(".collection_item");
    const searchInputValue = search.value.toLowerCase();

    allLi.forEach(f=>{
        if(f.firstChild.textContent.toLowerCase().indexOf.of(searchInputValue)===-1){
            f.style.display = "none";

        }
        else{
            f.style.display = "flex";
        }
    })
})